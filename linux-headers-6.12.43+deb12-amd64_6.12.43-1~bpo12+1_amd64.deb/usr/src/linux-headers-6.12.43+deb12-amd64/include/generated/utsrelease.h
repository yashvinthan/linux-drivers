#define UTS_RELEASE "6.12.43+deb12-amd64"
